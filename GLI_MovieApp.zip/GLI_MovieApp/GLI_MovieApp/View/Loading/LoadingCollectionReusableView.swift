//
//  LoadingCollectionReusableView.swift
//  GLI_MovieApp
//
//  Created by Jovan Alvin on 24/01/22.
//

import UIKit

class LoadingCollectionReusableView: UICollectionReusableView {
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
}

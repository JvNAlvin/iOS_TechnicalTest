//
//  ReviewCell.swift
//  GLI_MovieApp
//
//  Created by Jovan Alvin on 26/01/22.
//

import UIKit
import SDWebImage

class ReviewCellController: UITableViewCell {
    @IBOutlet weak var reviewImage: UIImageView!
    @IBOutlet weak var reviewName: UILabel!
    @IBOutlet weak var reviewText: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
}

//
//  ViewController.swift
//  GLI_MovieApp
//
//  Created by Jovan Alvin on 24/01/22.
//

import UIKit
import SDWebImage

class ViewController: UIViewController {
    
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var collectionView: UICollectionView!
    
    var isLoading = false
    var loadingView: LoadingCollectionReusableView?
    var viewModel = movieViewModel()
    var numberOfPage = 1
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        initRegister()
        initProcess()
        searchBar.placeholder = "Sorry Search Feature is not yet Working"
    }
    
}

extension ViewController {
    func initProcess() {
        viewModel.loadData(page: numberOfPage) { data in
            //Fetch & Store Data
            self.presentError(error: data)
            DispatchQueue.main.async {
                self.collectionView.reloadData()
            }
        }
    }
    
    func initRegister() {
        let loadingNib = UINib(nibName: "LoadingCollectionReusableView", bundle: nil)
        collectionView.register(loadingNib, forSupplementaryViewOfKind: UICollectionView.elementKindSectionFooter, withReuseIdentifier: "loadingReuse")
    }
}

extension ViewController: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 10
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 0, left: 10, bottom: 0, right: 10)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let numberOfSets = CGFloat(2)
        //182.5
        //274.5
        let width = 182.5//(collectionView.frame.size.width - (numberOfSets * view.frame.size.width / 15))/numberOfSets
        let height = 274.5//collectionView.frame.size.height / 2

        return CGSize(width: width, height: height)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForFooterInSection section: Int) -> CGSize {
        if self.isLoading {
            return CGSize.zero
        }
        else {
            return CGSize(width: collectionView.bounds.size.width, height: 55)
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        if kind == UICollectionView.elementKindSectionFooter {
            let FooterView = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "loadingReuse", for: indexPath) as! LoadingCollectionReusableView
            loadingView = FooterView
            loadingView?.backgroundColor = UIColor.clear
            return FooterView
        }
        return UICollectionReusableView()
    }
    
    func collectionView(_ collectionView: UICollectionView, willDisplaySupplementaryView view: UICollectionReusableView, forElementKind elementKind: String, at indexPath: IndexPath) {
        if elementKind == UICollectionView.elementKindSectionFooter {
            self.loadingView?.activityIndicator.startAnimating()
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didEndDisplayingSupplementaryView view: UICollectionReusableView, forElementOfKind elementKind: String, at indexPath: IndexPath) {
        if elementKind == UICollectionView.elementKindSectionFooter {
            self.loadingView?.activityIndicator.stopAnimating()
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        print("viewModelCount: \(viewModel.result.count)")
        return viewModel.result.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "collectionCell", for: indexPath) as! MovieCollectionViewCell
        //cell.movieImage.image = UIImage(named: "earth")
        cell.movieImage.sd_imageIndicator = SDWebImageActivityIndicator.gray
        cell.movieImage.sd_setImage(with: mergePath(path: viewModel.result[indexPath.row].posterPath ?? ""))
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        if indexPath.row == (viewModel.result.count-1) && !self.isLoading {
            loadMore()
        }
    }

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        print("selected: \(viewModel.result[indexPath.row].title)")
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let detailVC = storyBoard.instantiateViewController(withIdentifier: "DetailsViewController") as! DetailsViewController
        detailVC.movieDesc = viewModel.result[indexPath.row].overview
        detailVC.movieTitle = viewModel.result[indexPath.row].title
        detailVC.movieDate = viewModel.result[indexPath.row].releaseDate
        detailVC.movieID = viewModel.result[indexPath.row].id
        detailVC.movieRate = viewModel.result[indexPath.row].voteAverage
        detailVC.movieURL = viewModel.result[indexPath.row].posterPath
        self.navigationController?.pushViewController(detailVC, animated: true)
    }
    
    func loadMore() {
        if !self.isLoading {
            self.isLoading = true
            DispatchQueue.global().async {
                self.viewModel.loadData(page: self.numberOfPage+1) { data in
                    sleep(1)
                    self.presentError(error: data)
                    DispatchQueue.main.async {
                        self.collectionView.reloadData()
                        self.isLoading = false
                        self.numberOfPage = self.numberOfPage + 1
                    }
                }
            }
        }
    }
}



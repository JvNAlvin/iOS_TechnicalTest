//
//  MovieCollectionViewCell.swift
//  GLI_MovieApp
//
//  Created by Jovan Alvin on 24/01/22.
//

import UIKit

class MovieCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var movieImage: UIImageView!
}

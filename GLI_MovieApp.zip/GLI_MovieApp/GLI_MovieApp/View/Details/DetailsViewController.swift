//
//  DetailsViewController.swift
//  GLI_MovieApp
//
//  Created by Jovan Alvin on 25/01/22.
//

import UIKit
import WebKit
import SDWebImage

class DetailsViewController: UIViewController {
    @IBOutlet weak var webView: WKWebView!
    @IBOutlet weak var descriptionText: UILabel!
    @IBOutlet weak var movieImageView: UIImageView!
    @IBOutlet weak var movieTitleText: UILabel!
    @IBOutlet weak var movieDateText: UILabel!
    @IBOutlet weak var movieRateText: UILabel!
    @IBOutlet weak var tableView: UITableView!
    
    var movieTitle: String?
    var movieDate: String?
    var movieDesc: String?
    var movieURL: String?
    var movieID: Int?
    var movieRate: Double?
    
    var viewModel = ReviewViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        getTrailerURL(id: movieID ?? 0) { path in
            DispatchQueue.main.async {
                guard var videoURL = URL(string: "https://www.youtube.com/embed/\(path)?playsinline=1") else { return }
                let request = URLRequest(url: videoURL)
                self.webView.configuration.allowsInlineMediaPlayback = true
                self.webView.load(request)
            }
        }
        
        viewModel.getReview(id: movieID ?? 0) { output in
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
        }
        
        tableView.register(UINib(nibName: "ReviewCell", bundle: nil), forCellReuseIdentifier: "cell")
        tableView.rowHeight = UITableView.automaticDimension
        tableView.dataSource = self
        tableView.delegate = self
        
        setupView()
    }
    
    func setupView() {
        self.navigationItem.title = "\(movieTitle ?? "")"
        descriptionText.text = "\(movieDesc ?? "")"
        movieTitleText.text = "\(movieTitle ?? "")"
        movieDateText.text = "\(movieDate ?? "")"
        movieRateText.text = "\(movieRate ?? 0)"
        movieImageView.sd_imageIndicator = SDWebImageActivityIndicator.gray
        movieImageView.sd_setImage(with: mergePath(path: movieURL ?? ""))
    }
}

extension DetailsViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return CGFloat(150)
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if viewModel.reviewData?.count ?? 0 <= 5 {
            return viewModel.reviewData?.count ?? 0
        }
        return 5
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! ReviewCellController
        cell.reviewName.text = viewModel.reviewData?[indexPath.row].author
        cell.reviewText.text = viewModel.reviewData?[indexPath.row].content
        cell.reviewImage.sd_imageIndicator = SDWebImageActivityIndicator.gray
        var imageURL = viewModel.reviewData?[indexPath.row].authorDetails.avatarPath ?? "0"
        imageURL.removeFirst()
        cell.reviewImage.sd_setImage(with: URL(string: imageURL), placeholderImage: UIImage(systemName: "person.circle"))
        cell.reviewImage.layer.cornerRadius = 20
        return cell
    }
}

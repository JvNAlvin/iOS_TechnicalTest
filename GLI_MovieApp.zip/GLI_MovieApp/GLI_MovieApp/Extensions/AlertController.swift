//
//  AlertController.swift
//  GLI_MovieApp
//
//  Created by Jovan Alvin on 25/01/22.
//

import Foundation
import UIKit

extension ViewController {
    func presentError(error: String) {
        DispatchQueue.main.async {
            print("debug: \(error)")
            switch error {
            case "The Internet connection appears to be offline.":
                let alert = UIAlertController(title: "The Internet connection appears to be offline", message: "Try Again Later", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "OK", style: .default) { handle in
                    self.initProcess()
                })
                self.present(alert, animated: true, completion: nil)
            case "Unknown Error":
                let alert = UIAlertController(title: "Unknown Error", message: "Try Again Later", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "OK", style: .default) { handle in
                    self.initProcess()
                })
                self.present(alert, animated: true, completion: nil)
            case "Success":
                print("Load Success")
            default:
                print("Default")
            }
        }
    }
}

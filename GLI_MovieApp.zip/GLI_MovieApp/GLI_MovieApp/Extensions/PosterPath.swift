//
//  PosterPath.swift
//  GLI_MovieApp
//
//  Created by Jovan Alvin on 25/01/22.
//

import Foundation

func mergePath(path: String) -> URL {
    let mainPath = "https://image.tmdb.org/t/p/w185"
    return URL(string: mainPath + path)!
}


//
//  VideoRequest.swift
//  GLI_MovieApp
//
//  Created by Jovan Alvin on 25/01/22.
//

import Foundation
import Combine

func getTrailerURL(id: Int, completion: @escaping (_ data: String) -> Void) {
    guard let mainURL = URL(string: "https://api.themoviedb.org/3/movie/\(id)/videos?api_key=04c56a8a469a987ce3cf341217ff9664&language=en-US") else { return }
    URLSession.shared.dataTask(with: mainURL) { data, response, error in
        if let data = data {
            if let decodedData = try? JSONDecoder().decode(Video.self, from: data) {
                print("debug: \(decodedData.results.first?.key)")
                completion(decodedData.results.first?.key ?? "YE7VzlLtp-4")
            }
        }
        else {
            completion("YE7VzlLtp-4")
        }
    }.resume()
}

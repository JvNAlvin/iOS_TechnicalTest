//
//  ReviewRequest.swift
//  GLI_MovieApp
//
//  Created by Jovan Alvin on 26/01/22.
//

import Foundation

class ReviewViewModel: ObservableObject {
    @Published var reviewData: [ReviewResult]?
    
    func getReview(id: Int, completion: @escaping (_ data: String) -> Void) {
        guard let mainURL = URL(string: "https://api.themoviedb.org/3/movie/\(id)/reviews?api_key=04c56a8a469a987ce3cf341217ff9664") else { return }
        URLSession.shared.dataTask(with: mainURL) { data, response, error in
            if let data = data {
                if let decodedData = try? JSONDecoder().decode(Review.self, from: data) {
                    print("debug review: \(decodedData)")
                    self.reviewData = decodedData.results
                    completion("Success!")
                }
            }
            else {
                completion(error?.localizedDescription ?? "Unknown Error")
            }
        }.resume()
    }
}



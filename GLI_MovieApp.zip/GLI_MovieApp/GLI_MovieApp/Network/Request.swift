//
//  APIClient.swift
//  GLI_MovieApp
//
//  Created by Jovan Alvin on 24/01/22.
//

import Foundation
import Combine

class movieViewModel: ObservableObject {
    @Published var movieData: MovieData?
    @Published var result = [Result]()
    func loadData(page: Int, completion: @escaping (_ data: String) -> Void) {
        var urlComponents = URLComponents()
        urlComponents.scheme = "https"
        urlComponents.host = "api.themoviedb.org"
        urlComponents.path = "/3/movie/now_playing"
        urlComponents.queryItems = [
            URLQueryItem(name: "api_key", value: "04c56a8a469a987ce3cf341217ff9664"),
            URLQueryItem(name: "page", value: "\(page)")
        ]
        
        let task = URLSession.shared.dataTask(with: urlComponents.url!) { data, response, error in
            guard let data = data, error == nil else {
                print(error?.localizedDescription ?? "Unknown Error")
                completion("\(error?.localizedDescription ?? "Unknown Error")")
                return
            }
            do {
                let responseJSON = try JSONSerialization.jsonObject(with: data, options: .mutableContainers)
                let apiResponse = try JSONDecoder().decode(MovieData.self, from: data)
                self.movieData = apiResponse
                for item in apiResponse.results {
                    self.result.append(item)
                }
                completion("Success")
            }
            catch {
                completion("Unknown Error: \(error)")
            }
        }
        task.resume()
    }
}
